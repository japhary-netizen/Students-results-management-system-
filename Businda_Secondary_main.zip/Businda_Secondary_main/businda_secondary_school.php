<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "businda_school");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to calculate grade
function calculateGrade($marks) {
    if ($marks >= 80) return 'A';
    if ($marks >= 60) return 'B';
    if ($marks >= 40) return 'C';
    if ($marks >= 20) return 'D';
    return 'F';
}

// Handle Results Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $subject_id = $_POST['subject_id'];
    $marks = $_POST['marks'];

    // Insert result into the database
    $insertQuery = "INSERT INTO results (student_id, subject_id, marks) VALUES ('$student_id', '$subject_id', $marks)";
    if ($conn->query($insertQuery)) {
        echo "<p style='color:green;'>Result added successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
    }

    // Recalculate positions
    $positionsQuery = "
        SELECT students.id AS student_id, students.name AS student_name, SUM(results.marks) AS total_marks
        FROM students
        LEFT JOIN results ON students.id = results.student_id
        GROUP BY students.id
        ORDER BY total_marks DESC
";
    $positionsResult = $conn->query($positionsQuery);

    $position = 1;
    while ($row = $positionsResult->fetch_assoc()) {
        $updatePositionQuery = "
            UPDATE students
            SET position = $position
            WHERE id = " . $row['student_id'];
        $conn->query($updatePositionQuery);

        // Send SMS with grade and position
        if ($row['student_id'] == $student_id) {
            $grade = calculateGrade($marks);
            $message = "Dear Parent, your child, " . $row['student_name'] . 
", scored $marks in subject ID $subject_id. Grade: $grade. Position: $position.";
            $smsQuery = "INSERT INTO sms_queue (phone_number, message) VALUES (
                (SELECT phone_number FROM students WHERE id = $student_id), '$message')";
            $conn->query($smsQuery);
        }

        $position++;
    }
}

// Fetch Students and Subjects
$students = $conn->query("SELECT * FROM students");
$subjects = $conn->query("SELECT * FROM subjects");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Businda Secondary School - Add Results</title>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
</style>
</head>
<body>
<div class="container">
<h1>Businda Secondary School</h1>
<h2>Add Student Results</h2>
<form method="POST">
<!-- Select Student -->
<label for="student_id">Select Student:</label>
<select name="student_id" id="student_id" required>
<option value="">-- Choose Student --</option>
<?php while ($student = $students->fetch_assoc()) { ?>
<option value="<?= $student['id'] ?>"><?= $student['name'] ?> (Class: <?= $student['class'] ?>)</option>
<?php } ?>
</select>

<!-- Select Subject -->
<label for="subject_id">Select Subject:</label>
<select name="subject_id" id="subject_id" required>
<option value="">-- Choose Subject --</option>
<?php while ($subject = $subjects->fetch_assoc()) { ?>
<option value="<?= $subject['id'] ?>"><?= $subject['name'] ?></option>
<?php } ?>
</select>

<!-- Enter Marks -->
<label for="marks">Enter Marks:</label>
<input type="number" name="marks" id="marks" placeholder="Enter Marks (0-100)" required>

<!-- Submit Button -->
<button type="submit">Submit Result</button>
</form>
</div>
</body>
</html>

