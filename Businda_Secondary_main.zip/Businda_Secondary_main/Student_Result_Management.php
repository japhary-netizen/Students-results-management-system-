
<?php
// Initialize data array (replace this with database logic in production)
$data = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $subjects = $_POST['subjects'];
    $grades = $_POST['grades'];
    $position = $_POST['position'];

    // Combine subjects and grades into a readable string
    $subjectDetails = [];
    for ($i = 0; $i < count($subjects); $i++) {
        $subjectDetails[] = $subjects[$i] . " " . $grades[$i];
    }

    $data[] = [
        'name' => $name,
        'subjects' => implode(", ", $subjectDetails),
        'position' => $position
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Result Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        .form-group input, .form-group select, .form-group button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .form-group button {
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #218838;
        }
        .table-container {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #007bff;
            color: #fff;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Student Result Management</h1>
    <form method="POST">
        <div class="form-group">
            <label for="name">Student Name</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="subjects">Subjects</label>
            <div id="subject-container">
                <div class="subject-row">
                    <input type="text" name="subjects[]" placeholder="Subject" required>
                    <input type="text" name="grades[]" placeholder="Grade" required>
                </div>
            </div>
            <button type="button" onclick="addSubject()">Add Another Subject</button>
        </div>
        <div class="form-group">
            <label for="position">Position</label>
            <input type="number" id="position" name="position" required>
        </div>
        <div class="form-group">
            <button type="submit">Submit</button>
        </div>
    </form>

    <div class="table-container">
        <h2>Student Results</h2>
        <table>
            <thead>
            <tr>
                <th>Name</th>
                <th>Subjects and Grades</th>
                <th>Position</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['subjects']); ?></td>
                    <td><?php echo htmlspecialchars($row['position']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function addSubject() {
        const container = document.getElementById('subject-container');
        const newRow = document.createElement('div');
        newRow.className = 'subject-row';
        newRow.innerHTML = `
            <input type="text" name="subjects[]" placeholder="Subject" required>
            <input type="text" name="grades[]" placeholder="Grade" required>
        `;
        container.appendChild(newRow);
    }
</script>
</body>
</html>
