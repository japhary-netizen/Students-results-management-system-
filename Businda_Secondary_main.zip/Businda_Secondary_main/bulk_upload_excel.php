<?php
// Include PhpSpreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Database Connection
$conn = new mysqli("localhost", "root", "", "businda_school");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to calculate grade
function calculateGrade($marks) {
    if ($marks >= 80) return 'A';
    if ($marks >= 60) return 'B';
    if ($marks >= 40) return 'C';
    if ($marks >= 20) return 'D';
    return 'F';
}

// Handle Excel Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST'&& isset($_FILES['excel_file'])) {
    $file = $_FILES['excel_file']['tmp_name'];

    try {
        // Load the Excel file
        $spreadsheet = IOFactory::load($file);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        // Get subject IDs from the subjects table
        $subjectsQuery = "SELECT id, name FROM subjects";
        $subjectsResult = $conn->query($subjectsQuery);
        $subjects = [];
        while ($subject = $subjectsResult->fetch_assoc()) {
            $subjects[$subject['name']] = $subject['id'];
        }

        // Skip the first row (header)
        foreach (array_slice($rows, 1) as $row) {
            $student_id = $row[0];
            $student_name = $row[1];

            // Loop through the subjects and their respective marks
            foreach ($subjects as $subject_name => $subject_id) {
                $marks_column = array_search($subject_name, $row);
                if ($marks_column !== false) {
                    $marks = $row[$marks_column];

                    // Insert the result for each subject
                    $insertQuery = "INSERT INTO results (student_id, subject_id, marks) VALUES ('$student_id', '$subject_id', $marks)";
                    $conn->query($insertQuery);
                }
            }
        }

        // Recalculate positions
        $positionsQuery = "
            SELECT students.id AS student_id, students.name AS student_name, SUM(results.marks) AS total_marks
            FROM students
            LEFT JOIN results ON students.id = results.student_id
            GROUP BY students.id
            ORDER BY total_marks DESC
";
        $positionsResult = $conn->query($positionsQuery);

        $position = 1;
        while ($row = $positionsResult->fetch_assoc()) {
            $updatePositionQuery = "
                UPDATE students
                SET position = $position
                WHERE id = " . $row['student_id'];
            $conn->query($updatePositionQuery);

            // Send SMS with grade and position
            $grade = calculateGrade($row['total_marks']);
            $message = "Dear Parent, your child, " . $row['student_name'] . 
", has a total score of " . $row['total_marks'] . 
". Grade: $grade. Position: $position.";
            $smsQuery = "INSERT INTO sms_queue (phone_number, message) VALUES (
                (SELECT phone_number FROM students WHERE id = " . $row['student_id'] . "), '$message')";
            $conn->query($smsQuery);

            $position++;
        }

        echo "<p style='color:green;'>Results uploaded and processed successfully!</p>";
    } catch (Exception $e) {
        echo "<p style='color:red;'>Error: " . $e->getMessage() . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Businda Secondary School - Excel Bulk Upload</title>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
</style>
</head>
<body>
<div class="container">
<h1>Businda Secondary School</h1>
<h2>Bulk Upload Results (Excel)</h2>
<form method="POST" enctype="multipart/form-data">
<label for="excel_file">Upload Excel File:</label>
<input type="file" name="excel_file" id="excel_file" accept=".xlsx, .xls" required>
<button type="submit">Upload and Process</button>
</form>
<p><strong>Note:</strong> The Excel file should have the following columns:</p>
<ul>
<li><strong>Student ID</strong>: The ID of the student (as in the database).</li>
<li><strong>Student Name</strong>: The name of the student.</li>
<li><strong>Subject Columns</strong>: Each column should represent marks for a subject (the column name should match the subject name in the database).</li>
</ul>
</div>
</body>
</html>

