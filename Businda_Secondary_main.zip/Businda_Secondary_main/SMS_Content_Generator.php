
<?php
// Sample data for demonstration purposes
$name = "Juma"; // Student's name
$results = [
    "Chemistry" => "A",
    "Biology" => "B"
];
$position = "2"; // Position in class

// Construct the SMS message dynamically
$subjects = "";
foreach ($results as $subject => $grade) {
    $subjects .= "$subject $grade, ";
}
$subjects = rtrim($subjects, ", "); // Remove trailing comma

// Final SMS message
$sms = "Ndugu mzazi, mwanao $name. Amepata matokeo yafuatayo: $subjects. Na amekuwa MTU WA $position.";
echo $sms;
?>
