
<?php
// Sample data to export
$data = [
    ["Name", "Subject", "Grade", "Position"],
    ["Juma", "Chemistry", "A", 1],
    ["Aisha", "Biology", "B", 2]
];

// Export to CSV
if (isset($_POST['export_csv'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="data.csv"');
    $output = fopen("php://output", "w");
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// Export to Excel
if (isset($_POST['export_excel'])) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="data.xls"');
    echo "<table border='1'>";
    foreach ($data as $row) {
        echo "<tr>";
        foreach ($row as $cell) {
            echo "<td>" . htmlspecialchars($cell) . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Data</title>
</head>
<body>
    <h1>Export Student Data</h1>
    <form method="POST">
        <button type="submit" name="export_csv">Export to CSV</button>
        <button type="submit" name="export_excel">Export to Excel</button>
    </form>
</body>
</html>
