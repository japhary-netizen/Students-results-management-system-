<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "businda_school");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to calculate grade
function calculateGrade($marks) {
    if ($marks >= 80) return 'A';
    if ($marks >= 60) return 'B';
    if ($marks >= 40) return 'C';
    if ($marks >= 20) return 'D';
    return 'F';
}

// Handle Bulk Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST'&& isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];

    // Open the file for reading
    if (($handle = fopen($file, "r")) !== FALSE) {
        // Skip the header row
        fgetcsv($handle);

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $student_id = $data[0];
            $subject_id = $data[1];
            $marks = $data[2];

            // Insert result into the database
            $insertQuery = "INSERT INTO results (student_id, subject_id, marks) VALUES ('$student_id', '$subject_id', $marks)";
            $conn->query($insertQuery);
        }
        fclose($handle);

        // Recalculate positions
        $positionsQuery = "
            SELECT students.id AS student_id, students.name AS student_name, SUM(results.marks) AS total_marks
            FROM students
            LEFT JOIN results ON students.id = results.student_id
            GROUP BY students.id
            ORDER BY total_marks DESC
";
        $positionsResult = $conn->query($positionsQuery);

        $position = 1;
        while ($row = $positionsResult->fetch_assoc()) {
            $updatePositionQuery = "
                UPDATE students
                SET position = $position
                WHERE id = " . $row['student_id'];
            $conn->query($updatePositionQuery);

            // Send SMS with grade and position
            $grade = calculateGrade($row['total_marks']);
            $message = "Dear Parent, your child, " . $row['student_name'] . 
", has a total score of " . $row['total_marks'] . 
". Grade: $grade. Position: $position.";
            $smsQuery = "INSERT INTO sms_queue (phone_number, message) VALUES (
                (SELECT phone_number FROM students WHERE id = " . $row['student_id'] . "), '$message')";
            $conn->query($smsQuery);

            $position++;
        }

        echo "<p style='color:green;'>Results uploaded and processed successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error opening the file. Please try again.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Businda Secondary School - Bulk Upload</title>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
</style>
</head>
<body>
<div class="container">
<h1>Businda Secondary School</h1>
<h2>Bulk Upload Results</h2>
<form method="POST" enctype="multipart/form-data">
<label for="csv_file">Upload CSV File:</label>
<input type="file" name="csv_file" id="csv_file" accept=".csv" required>
<button type="submit">Upload and Process</button>
</form>
<p><strong>Note:</strong> The CSV file should have the following columns (without a header row):</p>
<ul>
<li><strong>Student ID</strong>: The ID of the student (as in the database).</li>
<li><strong>Subject ID</strong>: The ID of the subject (as in the database).</li>
<li><strong>Marks</strong>: The marks obtained by the student.</li>
</ul>
</div>
</body>
</html>

