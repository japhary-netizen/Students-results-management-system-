<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "businda_school");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Helper Function for Query Execution
function executeQuery($query) {
    global $conn;
    return $conn->query($query);
}

// Add Student
if (isset($_POST['add_student'])) {
    $name = $_POST['name'];
    $class = $_POST['class'];
    $phone = $_POST['phone'];

    $query = "INSERT INTO students (name, class, phone_number) VALUES ('$name', '$class', '$phone')";
    executeQuery($query);
    echo "Student added successfully!";
}

// Add Result
if (isset($_POST['add_result'])) {
    $student_id = $_POST['student_id'];
    $subject_id = $_POST['subject_id'];
    $marks = $_POST['marks'];

    $query = "INSERT INTO results (student_id, subject_id, marks) VALUES ('$student_id', '$subject_id', $marks)";
    executeQuery($query);

    // Send SMS to Parent
    $student_query = "SELECT * FROM students WHERE id = $student_id";
    $student = executeQuery($student_query)->fetch_assoc();
    $phone = $student['phone_number'];
    $message = "Dear Parent, your child, " . $student['name'] . ", scored $marks in subject ID $subject_id.";

    $sms_query = "INSERT INTO sms_queue (phone_number, message) VALUES ('$phone', '$message')";
    executeQuery($sms_query);

    echo "Result added and SMS queued successfully!";
}

// Process SMS Queue
if (isset($_POST['process_sms'])) {
    $query = "SELECT * FROM sms_queue WHERE status = 'pending'";
    $result = executeQuery($query);

    while ($row = $result->fetch_assoc()) {
        $phone = $row['phone_number'];
        $message = $row['message'];

        // Use Gammu to send SMS
        $command = "gammu-smsd-inject TEXT '$phone' -text \"$message\"";
        exec($command, $output, $return_var);

        if ($return_var == 0) {
            $updateQuery = "UPDATE sms_queue SET status = 'sent' WHERE id = " . $row['id'];
            executeQuery($updateQuery);
        }
    }
    echo "SMS processing complete!";
}

// Fetch Data
$students = executeQuery("SELECT * FROM students");
$subjects = executeQuery("SELECT * FROM subjects");
$results = executeQuery("SELECT r.*, s.name AS student_name FROM results r JOIN students s ON r.student_id = s.id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Businda Secondary School</title>
</head>
<body>
<h1>Businda Secondary School - Student Result Management System</h1>

<!-- Add Student -->
<h2>Add Student</h2>
<form method="POST">
<input type="text" name="name" placeholder="Student Name" required>
<input type="text" name="class" placeholder="Class" required>
<input type="text" name="phone" placeholder="Parent Phone Number" required>
<button type="submit" name="add_student">Add Student</button>
</form>

<!-- Add Result -->
<h2>Add Result</h2>
<form method="POST">
<select name="student_id" required>
<option value="">Select Student</option>
<?php while ($student = $students->fetch_assoc()) { ?>
<option value="<?= $student['id'] ?>"><?= $student['name'] ?></option>
<?php } ?>
</select>
<select name="subject_id" required>
<option value="">Select Subject</option>
<?php while ($subject = $subjects->fetch_assoc()) { ?>
<option value="<?= $subject['id'] ?>"><?= $subject['name'] ?></option>
<?php } ?>
</select>
<input type="number" name="marks" placeholder="Marks" required>
<button type="submit" name="add_result">Add Result</button>
</form>

<!-- Process SMS Queue -->
<h2>Process SMS</h2>
<form method="POST">
<button type="submit" name="process_sms">Send Pending SMS</button>
</form>

<!-- View Results -->
<h2>View Results</h2>
<table border="1">
<tr>
<th>Student Name</th>
<th>Subject ID</th>
<th>Marks</th>
</tr>
<?php while ($result = $results->fetch_assoc()) { ?>
<tr>
<td><?= $result['student_name'] ?></td>
<td><?= $result['subject_id'] ?></td>
<td><?= $result['marks'] ?></td>
</tr>
<?php } ?>
</table>
</body>
</html>

